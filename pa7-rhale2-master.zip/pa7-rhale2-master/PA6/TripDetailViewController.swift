//
//  TripDetailViewController.swift
//  PA7
//
//  This is the controller for the Detail View Contoller.
//  CPSC 315-02, Fall 2020
//  Programming Assignment #7
//  No sources to cite
//
//  Created by Rebekah Hale on 11/1/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//

import UIKit
import CoreData

/**
 This is the controller for the detail screen of the trip.
 */
class TripDetailViewController: UIViewController {
    var numOfTrips: Int = 0
    var totalTrips: Int = 0
    var tripOptional: Trip? = nil
    
    @IBOutlet var numOfTripsLabel: UILabel!
    @IBOutlet var destinationNameLabel: UILabel!
    @IBOutlet var startDateLabel: UILabel!
    @IBOutlet var endDateLabel: UILabel!
    @IBOutlet var tripImageView: UIImageView!
    
    
    /**
     Complies the view.
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let _ = Date()
        
        // Do any additional setup after loading the view.
        numOfTripsLabel.text = "Trip \(numOfTrips) of \(totalTrips)"
        if let trip = tripOptional {
            if let startDate = trip.startDate as Date?, let endDate = trip.endDate as Date?, let imageFileName = trip.imageFileName {
                let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                let fileURL = documentsDirectory.appendingPathComponent(imageFileName)
                destinationNameLabel.text = trip.destinationName
                startDateLabel.text = "\(dateFormatter.string(from: startDate))"
                endDateLabel.text = "\(dateFormatter.string(from: endDate))"
                let imageFromDisk = UIImage(contentsOfFile: fileURL.path)
                tripImageView.image = imageFromDisk
                
            }
        }
    }
    
    /**
     Executes before the segue and creas a new trip to be viewn in the Table Cell.
     
     - Parameter segue: The segue that is making the action occur.
     - Parameter sender: What is triggering the segue.
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let today = Date()
        
        if let identifier = segue.identifier {
            if (identifier == "SaveUnwindSegue") {
                if let destinationName = destinationNameLabel.text, let startDate = startDateLabel.text, let endDate = endDateLabel.text, let image = tripImageView.image {
                    if let trip = tripOptional {
                        trip.destinationName = destinationName
                        trip.startDate = dateFormatter.date(from: startDate) ?? today
                        trip.endDate = dateFormatter.date(from: endDate) ?? today
                        trip.imageFileName = image.description
                    }
                }
            }
        }
    }
}


