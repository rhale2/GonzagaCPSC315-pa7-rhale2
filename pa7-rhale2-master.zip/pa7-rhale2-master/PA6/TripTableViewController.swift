//
//  ViewController.swift
//  PA7
//
//  This is the main view for the Table View.
//  CPSC 315-02, Fall 2020
//  Programming Assignment #7
//  No sources to cite
//
//  Created by Rebekah Hale on 11/1/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//

import UIKit
import CoreData

/**
 Controlls the main view controller for Trips.
 */
class TripTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var trips = [Trip]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet var tableView: UITableView!
    
    /**
     Adds an editing mode to the Table View.
     
     - Parameter sender: The edit button.
     */
    @IBAction func editButtonPressed (_ sender: UIBarButtonItem) {
        let neeEditingMode = !tableView.isEditing
        tableView.setEditing(neeEditingMode, animated: true)
    }
    
    /**
     Grabs the Trip that was created in AddTableViewController and adds it to the table view cell.
     
     - Parameter segue: The segue from the Add button.
     */
    @IBAction func unwindFromAddTableViewContoller (segue: UIStoryboardSegue) {
        if let identifier = segue.identifier {
            if (identifier == "SaveUnwindSegue") {
                if let tripAddVC = segue.source as? AddTripViewController {
                    if let trip = tripAddVC.tripOptional {
                        trips.append(trip)
                        saveTrips()
                    }
                }
            }
        }
    }
    
    /**
     Complies the view.
     */
    override func viewDidLoad () {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let documentsDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        print(documentsDirectoryURL)
        
        loadTrips()
    }
    
    /**
     Sets how many rows there should be for the Table View.
     
     - Parameter tableView: The Table View.
     - Parameter section: The number of sections in the Table View.
     */
    func tableView (_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (section == 0) {
            return trips.count
        }
        return 0
    }
    
    /**
     Places a Trip in a cell.
     
     - Parameter tableView: The Table View.
     - Parameter indexPath: The cell position.
     */
    func tableView (_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let trip = trips[row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "TripCell", for: indexPath)
            as! TripTableViewCell
        cell.update(with: trip)
        return cell
    }
    
    /**
     Handles the moving of cells.
     
     - Parameter tableView: The Table View to edit.
     - Parameter sourceIndexPath: The original loctation of the cell.
     - Parameter destinationIndexPth: The new location of the cell.
     */
    func tableView (_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let trip = trips.remove(at: sourceIndexPath.row)
        trips.insert(trip, at: destinationIndexPath.row)
        saveTrips()
    }
    
    /**
     Handels the deletion of a cell.
     
     - Parameter tableView: The Table View.
     - Parameter editingStyle: The cell editing style.
     - Parameter indexPath: The cell position.
     */
    func tableView (_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            deleteTrips(tableView, commit: editingStyle, forRowAt: indexPath)
        }
    }
    
    /**
     Executes before the segue and grabs a new trip to be viewn in the Table Cell.
     
     - Parameter segue: The segue that is making the action occur.
     - Parameter sender: What is triggering the segue.
     */
    override func prepare (for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier {
            if identifier == "detailSegue" {
                if let tripDetailVC = segue.destination as? TripDetailViewController {
                    if let indexPath = tableView.indexPathForSelectedRow {
                        let trip = trips[indexPath.row]
                        tripDetailVC.tripOptional = trip
                        tripDetailVC.numOfTrips = indexPath.row + 1
                        tripDetailVC.totalTrips = trips.count
                    }
                }
            }
            else if (identifier == "AddSegue") {
                if let addTripVC = segue.destination as? AddTripViewController {
                    addTripVC.numOfTrips = trips.count + 1
                    if let indexPath = tableView.indexPathForSelectedRow {
                        tableView.deselectRow(at: indexPath, animated: true)
                        print("\(indexPath)")
                    }
                }
            }
        }
    }
    
    /**
     Saves the users trips to a database.
     */
    func saveTrips () {
        do {
            try context.save()
        } catch {
            print("Error saving trips \(error)")
        }
        tableView.reloadData()
    }
    
    /**
     Load the users trips from a database.
     */
    func loadTrips () {
        let request: NSFetchRequest<Trip> = Trip.fetchRequest()
        
        do {
            trips = try context.fetch(request)
        } catch {
            print("Error loading trips \(error)")
        }
        tableView.reloadData()
    }
    
    /**
     Handels the deletion of a Trip in the database.
     
     - Parameter tableView: The Table View.
     - Parameter editingStyle: The cell editing style.
     - Parameter indexPath: The cell position.
     */
    func deleteTrips (_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        context.delete(trips[indexPath.row])
        trips.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .fade)
        saveTrips()
    }
}

