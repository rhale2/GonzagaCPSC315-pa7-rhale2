//
//  TripDetailViewController.swift
//  PA6
//
//  Created by Rebekah Hale on 11/1/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//

import UIKit

/**
 This is the controller for the detail screen of the trip.
 */
class TripDetailViewController: UIViewController {
    var numOfTrips: Int = 0
    var totalTrips: Int = 0
    var tripOptional: Trip? = nil
    
    @IBOutlet var numOfTripsLabel: UILabel!
    @IBOutlet var destinationNameLabel: UILabel!
    @IBOutlet var startDateLabel: UILabel!
    @IBOutlet var endDateLabel: UILabel!
    @IBOutlet var tripImageView: UIImageView!
    
    /**
     Complies the view.
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        numOfTripsLabel.text = "Trip \(numOfTrips) of \(totalTrips)"
        if let trip = tripOptional {
            destinationNameLabel.text = trip.destinationName
            startDateLabel.text = "\(trip.dateFormatter.string(from: trip.startDate))"
            endDateLabel.text = "\(trip.dateFormatter.string(from: trip.endDate))"
            tripImageView.image = UIImage(named: trip.imageFileName ?? "Flower")
        
        }
    }
    
    /**
     Executes before the segue and creas a new trip to be viewn in the Table Cell.
     
     - Parameter segue: The segue that is making the action occur.
     - Parameter sender: What is triggering the segue.
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let today = Date()
        if let identifier = segue.identifier {
            if (identifier == "SaveUnwindSegue") {
                if let destinationName = destinationNameLabel.text, let startDate = startDateLabel.text, let endDate = endDateLabel.text, let image = tripImageView.image?.accessibilityIdentifier {
                    if let trip = tripOptional {
                        trip.destinationName = destinationName
                        trip.startDate = trip.dateFormatter.date(from: startDate) ?? today
                        trip.endDate = trip.dateFormatter.date(from: endDate) ?? today
                        trip.imageFileName = image
                    }
                }
            }
        }
    }
}
