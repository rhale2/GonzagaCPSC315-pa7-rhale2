//
//  AddTripViewController.swift
//  PA7
//
//  This is the controller for the Add Trip Screen.
//  CPSC 315-02, Fall 2020
//  Programming Assignment #7
//  No sources to cite
//
//  Created by Rebekah Hale on 11/2/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//

import UIKit
import CoreData
/**
 This is the contollrt for the Add Trip screen.
 */
class AddTripViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var numOfTrips: Int = 0
    var tripOptional: Trip? = nil
    
    
    @IBOutlet var numOfTripsLabel: UILabel!
    @IBOutlet var destinationNameTextField:  UITextField!
    @IBOutlet var startDateTextField: UITextField!
    @IBOutlet var endDateTextField: UITextField!
    @IBOutlet var tripImageView: UIImageView!
    
    /**
     Saves the image as a jpeg and grabs a file name for it.
     
     - Parameter image: The image that will be saved to the trip.
     */
    func saveImage (image: UIImage?) -> String {
        let filename = "\(UUID().uuidString).jpg"
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documentsDirectory.appendingPathComponent(filename)
        print(fileURL)
        print(documentsDirectory)
        if let unwrappedImage = image {
            if let data = unwrappedImage.jpegData(compressionQuality: 1.0),
               !FileManager.default.fileExists(atPath: fileURL.path) {
                do {
                    try data.write(to: fileURL)
                    return filename
                }
                catch {
                    print("Error saving file: \(error)")
                }
            }
        }
        return filename
    }
    
    /**
     Hnadles getting the image from the users photo album.
     
     - Parameter picker: Handles getting the image.
     - Parameter didFinishPickingMediaWithInfo: The info key of the image.
     */
    func imagePickerController (_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage =
            info[UIImagePickerController.InfoKey.originalImage]
            as? UIImage {
            tripImageView.image = selectedImage
            dismiss(animated: true, completion: nil)
        }
    }
    
    /**
     Executes when the add Image button is pressed.
     
     - Parameter sender: The save button that is pressed.
     */
    @IBAction func addImageButtonPressed (_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        
        let alertController = UIAlertController(title: "Choose Image Source", message: nil, preferredStyle: .actionSheet)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let cameraAction = UIAlertAction(title: "Camera", style:
                                                .default, handler: { action in
                                                    imagePicker.sourceType = .camera
                                                    self.present(imagePicker, animated: true,
                                                                 completion: nil
                                                    )})
            alertController.addAction(cameraAction)
        }
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let photoLibraryAction = UIAlertAction(title: "photo library", style: .default, handler: { action in
                imagePicker.sourceType = .photoLibrary
                self.present(imagePicker, animated: true,
                             completion: nil)
            })
            alertController.addAction(photoLibraryAction)
        }
        present(alertController, animated: true, completion: nil)
    }
    
    /**
     Dismisses the keyboard when the background is tapped.
     
     - Parameter sender: The baclground of the view.
     */
    @IBAction func backGroundPressed (_ sender: UITapGestureRecognizer) {
        destinationNameTextField.resignFirstResponder()
        startDateTextField.resignFirstResponder()
        endDateTextField.resignFirstResponder()
    }
    
    /**
     Validates and checks to make sure there is data for the each of the textFields.
     
     - Parameter sender: The save button that is pressed.
     */
    @IBAction func saveButtonPressed (_ sender: UIButton) {
        if (destinationNameTextField.text == "") {
            let alert = UIAlertController(title: "You need a Destination Name to save a Trip",
                                          message: nil, preferredStyle: .alert)
            alert.addTextField(configurationHandler: { texField in
                texField.placeholder = "Enter a Destination Name"
            })
            alert.addAction (UIAlertAction(title: "Okay", style: .default, handler: { _ in
                let destination = alert.textFields?.first?.text
                self.destinationNameTextField.text = destination
            }))
            self.present(alert, animated: true)
        }
        if (startDateTextField.text == "") {
            let alert = UIAlertController(title: "You need a Start Date to save a Trip",
                                          message: nil, preferredStyle: .alert)
            alert.addTextField(configurationHandler: { texField in
                texField.placeholder = "Enter a Start Date MM/DD/YYYY"
            })
            alert.addAction (UIAlertAction(title: "Okay", style: .default, handler: { _ in
                let destination = alert.textFields?.first?.text
                
                self.startDateTextField.text = destination
            }))
            self.present(alert, animated: true)
        }
        if (endDateTextField.text == "") {
            let alert = UIAlertController(title: "You need a End Date to save a Trip",
                                          message: nil, preferredStyle: .alert)
            alert.addTextField(configurationHandler: { texField in
                texField.placeholder = "Enter a End Date MM/DD/YYYY"
            })
            alert.addAction (UIAlertAction(title: "Okay", style: .default, handler: { _ in
                let destination = alert.textFields?.first?.text
                self.endDateTextField.text = destination
            }))
            self.present(alert, animated: true)
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let today = Date()
        
        let startDateString = startDateTextField.text ?? "nope"
        let badStartDate = dateFormatter.date(from: startDateString) ?? today
        
        
        if (badStartDate == today) {
            let alert = UIAlertController(title: "You need a Valid Start Date to save a Trip",
                                          message: nil, preferredStyle: .alert)
            alert.addTextField(configurationHandler: { texField in
                texField.placeholder = "Enter a a Valid Start Date MM/DD/YYYY"
            })
            alert.addAction (UIAlertAction(title: "Okay", style: .default, handler: { _ in
                let destination = alert.textFields?.first?.text
                self.startDateTextField.text = destination
            }))
            self.present(alert, animated: true)
        }
        
        let endDateString = endDateTextField.text ?? "nope"
        print(endDateString)
        let badEndDate = dateFormatter.date(from: endDateString) ?? today
        
        
        if (badEndDate == today) {
            let alert = UIAlertController(title: "You need a Valid End Date to save a Trip",
                                          message: nil, preferredStyle: .alert)
            alert.addTextField(configurationHandler: { texField in
                texField.placeholder = "Enter a Valid End Date MM/DD/YYYY"
            })
            alert.addAction (UIAlertAction(title: "Okay", style: .default, handler: { _ in
                let destination = alert.textFields?.first?.text
                self.endDateTextField.text = destination
            }))
            self.present(alert, animated: true)
        }
        
        
        if (destinationNameTextField.text != "" && startDateTextField.text != "" && endDateTextField.text != "" && badStartDate != today && badEndDate != today) {
            self.performSegue(withIdentifier: "SaveUnwindSegue", sender: self)
        }
    }
    
    /**
     The keyboard is hidden when the return button is pressed.
     
     - Parameter textField: The Text Field is changed.
     */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // this callback is executed when the user presses the return key on the keypad
        print("return")
        textField.resignFirstResponder()
        return true
    }
    
    /**
     Complies the view.
     */
    override func viewDidLoad () {
        super.viewDidLoad()
        if (numOfTrips == 0) {
            numOfTrips = 1
        }
        numOfTripsLabel.text = "Add Trip #\(numOfTrips)"
        // Do any additional setup after loading the view.
        
    }
    
    /**
     Executes before the segue and sends the Ttrip created to be viewn in the Table Cell.
     
     - Parameter segue: The segue that is making the action occur.
     - Parameter sender: What is triggering the segue.
     */
    override func prepare (for segue: UIStoryboardSegue, sender: Any?) {
        let tripVC = TripTableViewController()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let _ = Date()
        
        if let identifier = segue.identifier {
            if identifier == "SaveUnwindSegue" {
                if let destinationName = destinationNameTextField.text, let startDate = startDateTextField.text, let endDate = endDateTextField.text, let image = tripImageView.image {
                    let trip = Trip(context: tripVC.context)
                    let imageURL = saveImage(image: image)
                    trip.destinationName = destinationName
                    trip.startDate = dateFormatter.date(from: startDate)
                    trip.endDate = dateFormatter.date(from: endDate)
                    trip.imageFileName = imageURL
                    tripOptional = trip
                    saveTrips(context: tripVC.context)
                }
            }
        }
    }
    
    /**
     Saves the users trips to a database.
     */
    func saveTrips (context: NSManagedObjectContext) {
        do {
            try context.save()
        } catch {
            print("Error saving trips \(error)")
        }
    }
}
