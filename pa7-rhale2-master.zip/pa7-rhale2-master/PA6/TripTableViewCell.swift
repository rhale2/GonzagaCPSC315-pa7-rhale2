//
//  TripTableViewCell.swift
//  PA7
//
//  This is the controller for the cell prototype.
//  CPSC 315-02, Fall 2020
//  Programming Assignment #7
//  No sources to cite
//
//  Created by Rebekah Hale on 11/1/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//

import UIKit
/**
 Creates an instance of a Cell for the Table View
 */
class TripTableViewCell: UITableViewCell {
    @IBOutlet var destinationNameLabel: UILabel!
    @IBOutlet var startEndDateLabel: UILabel!
    @IBOutlet var tripImageView: UIImageView!
    
    /**
     Initialization code
     */
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    /**
     Sets a cell as selected/
     
     - Parameter selected: If the cell is selcted or not.
     - Parameter animated: The animation.
     */
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    /**
     Updates the cells view.
     
     - Parameter trip: The Trip to be sent into the cell.
     */
    func update (with trip: Trip) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let _ = Date()
        
        if let startDate = trip.startDate as Date?, let endDate = trip.endDate as Date?, let imageFileName = trip.imageFileName {
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            destinationNameLabel.text = trip.destinationName
            startEndDateLabel.text = "\(dateFormatter.string(from: startDate)) - \(dateFormatter.string(from: endDate))"
            let fileURL = documentsDirectory.appendingPathComponent(imageFileName)
            print("image file name: \(imageFileName)")
            let imageFromDisk = UIImage(contentsOfFile: fileURL.path)
            tripImageView.image = imageFromDisk
            
        }
    }
}
