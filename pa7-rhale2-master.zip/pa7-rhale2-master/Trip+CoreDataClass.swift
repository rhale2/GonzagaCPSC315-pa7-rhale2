//
//  Trip+CoreDataClass.swift
//  PA7
//
//  This is the NSManaged Object Class.
//  CPSC 315-02, Fall 2020
//  Programming Assignment #7
//  No sources to cite
//
//  Created by Rebekah Hale on 11/15/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Trip)
public class Trip: NSManagedObject {

}
