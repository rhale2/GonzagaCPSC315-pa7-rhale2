//
//  Trip+CoreDataProperties.swift
//  PA7
//
//  This is the controller for the cell prototype.
//  CPSC 315-02, Fall 2020
//  Programming Assignment #7
//  No sources to cite
//
//  Created by Rebekah Hale on 11/16/20.
//  Copyright © 2020 Rebekah Hale. All rights reserved.
//
//

import Foundation
import CoreData


extension Trip {

    /**
     Returns the request.
     */
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Trip> {
        return NSFetchRequest<Trip>(entityName: "Trip")
    }

    @NSManaged public var destinationName: String?
    @NSManaged public var endDate: Date?
    @NSManaged public var imageFileName: String?
    @NSManaged public var startDate: Date?

}

extension Trip : Identifiable {

}
